package umontreal.ssj.networks;

import java.util.LinkedList;
import java.util.List;

//import connectivity.*;
//import util.Tools;
import umontreal.ssj.rng.*;

/**
 * 
 * Implements the generalized splitting algorithm. This algorithm is used to obtain an
 * estimate of a rare event probability via Gibbs sampling. 
 * See Zdravko thesis for more details.
 * The main parameters to run the algorithm are: <menu>
 * <li>a Markov chain</li>
 * <li>a number of Markov chain at the beginning of the simulation</li>
 * <li>the splitting factors</li>
 * <li>the gamma levels</li>
 * </menu>
 * 
 */
public class GeneralizedSplittingBotev
{
   private double[] m_ell;      // estimate of rare-event probability
   private double[] m_var;      // estimate of variance of ell
   private int[] m_NT;          // size of set at level T


   /**
    * Return the splitting Factors according with ADAM's algorithm. At the end,
    * we have a NT-dimensional vector.
    * 
    * @param Nt
    *           the number of markov chain at the current gamma level
    * @param rho
    *           the splitting factor used
    * @param stream
    * @return a Nt-dimensional vector wich contain the splitting factors
    *         for each markov chain
    */
   private int[] getSplittingFactors(int Nt, double rho, RandomStream stream)
   {
      int[] split = new int[Nt];
      for (int i = 0; i < Nt; i++) {
         double frac = 1 / rho;
         boolean ber = stream.nextDouble() < (frac - Math.floor(frac));
         if (ber) {
            split[i] = (int) (Math.floor(frac) + 1);
         } else {
            split[i] = (int) (Math.floor(frac));
         }
      }
      return split;
   }
   
   
   /**
    * Returns the estimate of the rare-event probability.
    * @param N0 number of chains at level 0
    * @param NT number of chains at level T
    * @param rho inverse of the splitting factors s[i] = 1/rho[i]
    * @return the estimate of the rare-event probability.
    */
   private double calcEstimateEll (int N0, int NT, double[] rho)
   {
      int T = rho.length - 1;
      double ell = 1;
      for (int i = 1; i <= T; i++)
         ell *= rho[i];
      ell *= (double) NT / N0;
      return ell;
   }


   /**
    * Returns the estimate of the variance of the rare-event probability.
    * @param N0 number of chains at level 0
    * @param NT number of chains at level T
    * @param rho inverse of the splitting factors s[i] = 1/rho[i]
    * @param numOi Number of final chains that have initial ancestor i
    * @return the estimate of the variance of ell
    */
   private double calcVarianceEll (int N0, int NT, int nn, double[] rho, int[] numOi)
   {
      int T = rho.length - 1;
      double estimate = 1;
      for (int i = 1; i <= T; i++)
         estimate *= rho[i] * rho[i];
      estimate /= (N0 * (N0 - rho[1]));

      double sum = 0;
      for (int j = 0; j < nn; j++) {
         double tem = numOi[j] - rho[1] * NT / N0;
         sum += tem * tem;
      }
      return estimate * sum;
   }


   /**
    * Gives an estimate of rare-event probability by the splitting 
    * algorithm with Gibbs sampling and fixed gamma levels. Does only
    * one run.
    * 
    * @param mother
    *           initial Markov chain to be cloned
    * @param N
    *           sample size
    * @param gamma
    *           gamma levels
    * @param rho
    *           splitting factors
    * @param stream
    *           random stream
    * @param s
    *        s-th run
    * @param printFlag
    *           printing flag: if false, don't print anything
    * @return the number of chains reaching the final level
    */
   private void doOneRun(MarkovChain mother, int N, double[] gamma,
                         double[] rho, RandomStream stream, int s,
                         boolean printFlag)
   {
      // EPSF to ensure floors are computed correctly: [n + EPSF] = n
   	// even with floating-point errors
      final double EPSF = 1.0e-15;
      
      int T = gamma.length - 1;        // number of levels
      int[] RandNT = new int[T + 1];   // N_t
      RandNT[0] = (int) (EPSF + rho[1] * (Math.floor(N / rho[1])));
      int nn = (int) (EPSF + RandNT[0]/rho[1]);       // N0/rho[1]
      int[] numOi = new int[nn];     // number of survivors with ancestor i
      
      List<MarkovChain> list0 = new LinkedList<MarkovChain>();
      List<MarkovChain> list1 = new LinkedList<MarkovChain>();

      for (int i = 0; i < nn; i++) {
         // iterate over nn initial chains; they're all copies of mother
         MarkovChain chain = mother.clone();
         chain.initialState(stream);
         chain.setGammaLevel(gamma[1]);
         if (!chain.isImportanceGamma(gamma[1]))
            continue;
         ++RandNT[1];
         list1.add(chain);

         int split;   // split factor
         int t = 1;   // gamma level = t;

         // iterate over all levels of gamma for this chain
         while (t < T && list1.size() > 0) {
         //	System.out.println ("t = " + t + "   Gam = " + gamma[t]);
           // select all Markov chains on the list of old survivors
            split = (int) (EPSF + 1.0 / rho[t+1]);
            for (MarkovChain chain1 : list1) {
               MarkovChain newchain = chain1.clone();
               for (int j = 0; j < split; j++) {
                  // Markov sampling; advance split steps
                  newchain.nextStep(stream);
                  list0.add(newchain);
               }
            }   // we have our new subset X_t
            list1.clear();

            t++;
            for (MarkovChain chain0 : list0) {
               chain0.setGammaLevel(gamma[t]);
               if (chain0.isImportanceGamma(gamma[t]))
                  list1.add(chain0);
            }
            list0.clear();
            RandNT[t] += list1.size();
         }

         if (t >= T) {
            // Count number of final chains that have initial ancestor i
            numOi[i] = list1.size();
         } else {
            // evolution stopped before T since 0 chain survived
            numOi[i] = 0;
         }
         list1.clear();
      }

      // System.out.println(Tools.toStringNonZero("numOi", numOi));

      m_ell[s] = calcEstimateEll (RandNT[0], RandNT[T], rho);
      if (printFlag)
         System.out.printf("estimate ell  = %g%n", m_ell[s]);

      m_var[s] = calcVarianceEll (RandNT[0], RandNT[T], nn, rho, numOi);
      if (printFlag) {
         double sig = Math.sqrt(m_var[s]);
         System.out.printf("sigma (ell)   = %g%n", sig);
         //	System.out.printf("estimate Var(ell) = %g%n", var);
         System.out.printf("[ell - 2*sigma, ell + 2*sigma] = [%8.4g, %8.4g]%n",
                           m_ell[s] - 2*sig, m_ell[s] + 2*sig);
      }

      // resultsOne = new GibbsResultsOfOneSimulation(ell, RandNT);
      // resultsOne.setEstimate(ell);
      m_NT[s] = RandNT[T];
      System.out.println("\nnumber of survivors = " + Tools.sum(numOi));
   }

   /**
    * Run the algorithm many times and return the basic parameters of the
    * estimator (i.e. mean and standard deviation).
    * THIS METHOD IS NOT FINISHED. Check the statistics for numRun > 1.
    * 
    * @param mother
    *           mother of all Markov chains
    * @param numRun
    *           the number of runs
    * @param numChain
    *           the number of Markov chains at the beginning
    * @param Gamma
    *           the gamma levels
    * @param Rho
    *           the splitting factors
    * @return the relative error of Gibbs estimator
    */
   public double run(MarkovChain mother, int numRun, int numChain,
                     double[] Gamma, double[] Rho, RandomStream stream)
   {
      if (numRun != 1)
      	throw new IllegalArgumentException ("numRun must be = 1 for now");
      m_ell = new double[numRun];
      m_var = new double[numRun];
      m_NT = new int[numRun];
      
      boolean flag;        // printing flag in doOneRun
      if (numChain == 1)
         flag = false;
      else
         flag = true;
      
      mother.setGammaLevel(Gamma[0]);
      // int[][] Y = new int[numRun][Gamma.length];
      for (int i = 0; i < numRun; i++) {
         doOneRun(mother, numChain, Gamma, Rho, stream, i, flag);
         /*
          ELL[i] = resultsOne.estimate;

          for (int j = 0; j < Gamma.length; j++) {
          Y[i][j] = resultsOne.numberAtEachLevel[j];
            Y[i] = resultsOne.numberAtEachLevel[Gamma.length - 1];
          }
          */
      }

      double mean = 0;
      for (int i = 0; i < numRun; i++)
         mean += m_ell[i];
      mean /= numRun;

      double sum = 0;
      for (int i = 0; i < numRun; i++) {
         // System.out.println("ELL = " + ELL[i]);
         sum += (m_ell[i] - mean) * (m_ell[i] - mean);
      }

      double std = 0;
      double RE = 0;

      if (numRun > 1) {
         sum /= (numRun - 1);
         //**** ?? var = sum/(numRun*(numRun - 1));
         std = Math.sqrt(sum);
         RE = std / (Math.sqrt(numRun) * mean);
         System.out.println("mean = " + mean);
         System.out.println("std = " + std);
         System.out.println("RE = " + RE);
      }
/*
      double Estimator = 1;
      for (int i = 0; i < Gamma.length; i++) {
         Estimator *= Rho[i] * Rho[i];
      }
      Estimator /= (1 * (1 - Rho[0]));
      double S = 0;
      for (int j = 0; j < 1.0 / Rho[0]; j++) {
         double tem = Y[j][Gamma.length - 1] - Rho[0] * Y[j][Gamma.length - 1];
         S += tem * tem;
      }

       double var = Estimator * S;
       resultsN = new GibbsResultsOfNSimulations(ELL, Y, mean, std * std, RE,
       rhoAdam, var);
*/
      return RE;
   }
}
