/**
 * 
 */
package umontreal.ssj.networks;

/**
 * @author simardr
 * 
 */
public enum SamplerType {
	NON_INIT, UNIFORM, EXPONENTIAL, NORMAL
}
