
package umontreal.ssj.networks;


//import connectivity.*;
//import util.*;
import java.util.*;
import umontreal.ssj.rng.*;

/**
 * This class implements the ADAM (ADAptative Multilevel splitting) algorithm.
 * This algorithm is used as a pilot run to estimate the splitting factors
 * and the gamma levels. See Zdravko Botev's thesis for more details.
 * The main parameters to run the ADAM algorithm are
 * <menu>
 * <li>a Markov chain</li>
 * <li>a constant number of Markov chains at the beginning of each level</li>
 * <li>a splitting factor rho</li>
 * <li>the first gamma level</li>
 * <li>the target gamma level</li>
 * </menu>
 */
public class AdamSplittingBotev
{
   private double[] m_Gamma;   // gamma levels

   private double[] m_Rho;    // splitting factors
 
   private double m_el;     // l_Adam estimator

   /**
    * ADAM Algorithm gives an estimator of a rare-event probability.
    *
    * @param mother mother of all Markov chains created by the ADAM Algorithm
    * @param N constant number of Markov chains at the beginning of each level
    * @param rho rarity [in (0, 1)]
    * @param stream to advance the Markov chains
    * @param streamS to modify the splitting factors
    * @param firstGammaLevel the first level
    * @param finalGammaLevel the target level
    * @return the ADAM estimator
    */
   public double run (MarkovChain mother, int N, double rho, RandomStream stream,
   		             RandomStream streamS, double firstGammaLevel, double finalGammaLevel)
   {
      LinkedList <MarkovChain> list0 = new LinkedList <MarkovChain> ();
      LinkedList <MarkovChain> list1 = new LinkedList <MarkovChain> ();
      ArrayList <Double> gammaT = new ArrayList <Double> ();
      ArrayList <Double> rhoT = new ArrayList <Double> ();
      ArrayList <Integer> RandNT = new ArrayList <Integer> ();
      double[] tabS = new double[N];
 
      mother.setGammaLevel (firstGammaLevel);

      for (int i = 0; i < N; i++) {
         MarkovChain chain0 = mother.clone ();
         chain0.initialState (stream);
         list0.add (chain0);
      }

      double currentGammaT = firstGammaLevel;
      gammaT.add (currentGammaT);

      // select survivors; when firstGammaLevel = 0, this is unnecessary
      for (MarkovChain chain: list0) {
         if (chain.isImportanceGamma (currentGammaT)) {
            list1.add (chain);
         }
      }

      int currentRandNT = list1.size ();
      RandNT.add (currentRandNT);
      double currentRhoT = currentRandNT / (double) N;
      rhoT.add (currentRhoT);

      // don't need list0 anymore
      list0.clear ();

      int t = 1;
      while (currentGammaT < finalGammaLevel) {
         int[] split;
         split = getSplitFactors (N, currentRandNT, streamS);

         int co = -1;
         for (MarkovChain chain1: list1) {
            // select each MarkovChain in the list of old survivors
            co++;
            MarkovChain newchain = chain1.clone ();
            for (int i = 0; i < split[co]; i++) {
               newchain.nextStep (stream);
               list0.add (newchain);
            }                     // we do that split[co] times
         }                        // we have our new subset Xt

         // don't need list1 anymore
         list1.clear ();
         
         int i = 0;
         for (MarkovChain chain: list0) {
            tabS[i++] = chain.getImportance ();
         }

         currentGammaT = Math.min (getNextGamma (N, rho, tabS), finalGammaLevel);
         gammaT.add (currentGammaT);

         // update for next gamma level; keep only chains which are 
         // non-operational at time = next gamma
         for (MarkovChain chain: list0) {
            chain.setGammaLevel (currentGammaT);
            if (chain.isImportanceGamma (currentGammaT)) {
               list1.add (chain);
            }
         }
         list0.clear ();
//         System.out.println("size1 = "+ list1.size());

         currentRandNT = list1.size ();
         RandNT.add (currentRandNT);
         if (currentRandNT <= 0) {
         	System.out.println("0 chain survivor at this level");
            break;
         }
          
         currentRhoT = currentRandNT / (double) N;
         rhoT.add (currentRhoT);

         t++;
      }

      // estimator 
      m_el = 1;
      for (Double d: rhoT)
         m_el *= d;

      int m = gammaT.size();
      m_Gamma = new double[m];
      for (int i = 0; i < m; i++)
      	m_Gamma[i] = gammaT.get(i);
      
      m = rhoT.size();
      m_Rho = new double[m];
      for (int j = 0; j < m; j++)
      	m_Rho[j] = rhoT.get(j);

      return m_el;
   }



   /**
    * Returns the splitting factors according to the ADAM algorithm.
    * At the end, we have a splitting vector of dimension NT. 
    * Since NT generally does not divide N exactly, we add 1 to 
    * some splitting factors chosen randomly, so that the sum of all
    * splitting factors is exactly equal to N.
    *
    * @param N constant number of Markov chains at the beginning of each level
    * @param NT number of Markov chains at the current level gamma
    * @param stream to change splitting factors by 0 or 1 randomly.
    * @return the splitting factors for each of NT Markov chains
    */
   public int[] getSplitFactors (int N, int NT, RandomStream stream)
   {
      int[] splitFactors = new int[NT];
      int commonValue = N / NT;
      for (int i = 0; i < NT; i++) {
         splitFactors[i] = commonValue;
      }
 
      int[] tab = new int[NT];
      RandomPermutation.init(tab, NT);   // numbers {1, 2,..., NT}
      RandomPermutation.shuffle(tab, stream);
      int r = N % NT;
      int j;
      for (int i = 0; i < r; i++) {
         j = tab[i] - 1;    // j = index in {0, 1,..., NT-1}
         ++splitFactors[j];
      }
      return splitFactors;
   }

   /**
    * Returns the next gamma level. It is the element of tab such that
    * N*rho elements are larger (or equal) than the element itself.
    *
    * @param N constant number of Markov chains at the beginning of each level
    * @param rho splitting factor
    * @param tab An N-dimensional vector which contains the value of the
    *     importance function of each Markov chain
    * @return the new gamma level
    */
   private double getNextGamma (int N, double rho, double[] tab)
   {
   	final int m = tab.length;
      Arrays.sort (tab);
      int k = N - (int) (N*rho) - 1;
      return tab[Math.min (k, m - 1)];
   }

   
   /**
    * Prints the gamma levels and the splitting factors obtained from
    * the ADAM algorithm (after calling the <tt>run</tt> method).
    *
    */
   public void print ()
   {
      System.out.println ("Adam algorithm : estimator = " + m_el);
      for (int i = 0; i < m_Gamma.length; i++) {
         System.out.println ("level " + i + " = " + m_Gamma[i]);
      }

      for (int i = 0; i < m_Rho.length; i++) {
         System.out.println ("splitting " + i + " = " + m_Rho[i]);
      }
   }
   
   
   /**
    * @return the splitting factors.
    */
   public double[] getRho ()
   {
      return m_Rho;
   }
   
   /**
    * 
    * @return the gamma levels.
    */
   public double[] getGamma ()
   {
      return m_Gamma;
   }
   
   public double getL ()
   {
      return m_el;
   }

}
